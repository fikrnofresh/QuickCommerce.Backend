﻿using Microsoft.EntityFrameworkCore;
using QuickCommerce.Core.DTOs.AdminUsers;
using QuickCommerce.Core.Entities;
using QuickCommerce.Core.Interfaces;
using QuickCommerce.Infrastructure.Data;
using QuickCommerce.Infrastructure.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickCommerce.Infrastructure.Services
{
    public class AdminUserService : IAdminUserService
    {
        private readonly ApplicationDbContext _context;
        private readonly AuditLogService _auditLogService;

        public AdminUserService(
            ApplicationDbContext context,
            AuditLogService auditLogService)
        {
            _context = context;
            _auditLogService = auditLogService;
        }

        // =========================
        // CREATE USER
        // =========================
        public async Task<AdminUserResponseDto> CreateAdminUserAsync(CreateAdminUserDto dto)
        {
            var user = new User
            {
                PhoneNumber = dto.PhoneNumber,
                IsPhoneVerified = true,
                CreatedAt = DateTime.UtcNow
            };

            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();

            var userRole = new UserRole
            {
                UserId = user.Id,
                RoleId = dto.RoleId,
                GrantedAt = DateTime.UtcNow
            };

            await _context.UserRoles.AddAsync(userRole);
            await _context.SaveChangesAsync();

            var role = await _context.Roles.FirstAsync(r => r.Id == dto.RoleId);

            // 🔥 AUDIT LOG
            await _auditLogService.LogAsync(
                userId: null,
                module: "USERS",
                action: "CREATE_USER",
                entityType: "User",
                entityId: user.Id,
                description: $"Admin user created with role {role.Name}"
            );

            return new AdminUserResponseDto
            {
                Id = user.Id,
                PhoneNumber = user.PhoneNumber,
                Role = role.Name
            };
        }

        public async Task<IEnumerable<AdminUserResponseDto>> GetAllAdminUsersAsync()
        {
            return await _context.Users
                .Join(_context.UserRoles,
                    u => u.Id,
                    ur => ur.UserId,
                    (u, ur) => new { u, ur })
                .Join(_context.Roles,
                    temp => temp.ur.RoleId,
                    r => r.Id,
                    (temp, r) => new AdminUserResponseDto
                    {
                        Id = temp.u.Id,
                        PhoneNumber = temp.u.PhoneNumber,
                        Role = r.Name
                    })
                .ToListAsync();
        }

        public async Task<AdminUserResponseDto?> GetAdminUserByIdAsync(int id)
        {
            return await _context.Users
                .Where(u => u.Id == id)
                .Join(_context.UserRoles,
                    u => u.Id,
                    ur => ur.UserId,
                    (u, ur) => new { u, ur })
                .Join(_context.Roles,
                    temp => temp.ur.RoleId,
                    r => r.Id,
                    (temp, r) => new AdminUserResponseDto
                    {
                        Id = temp.u.Id,
                        PhoneNumber = temp.u.PhoneNumber,
                        Role = r.Name
                    })
                .FirstOrDefaultAsync();
        }

        public async Task<bool> UpdateAdminUserAsync(int id, UpdateAdminUserDto dto)
        {
            var userRole = await _context.UserRoles
                .FirstOrDefaultAsync(x => x.UserId == id);

            if (userRole == null)
                return false;

            var oldRoleId = userRole.RoleId;

            userRole.RoleId = dto.RoleId;

            await _context.SaveChangesAsync();

            // 🔥 LOG
            await _auditLogService.LogAsync(
                userId: id,
                module: "USERS",
                action: "UPDATE_ADMIN_USER",
                entityType: "User",
                entityId: id,
                description: $"Admin user role updated from {oldRoleId} to {dto.RoleId}"
            );

            return true;
        }

        public async Task<bool> DeleteAdminUserAsync(int id)
        {
            var user = await _context.Users.FindAsync(id);

            if (user == null)
                return false;

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            // 🔥 LOG
            await _auditLogService.LogAsync(
                userId: id,
                module: "USERS",
                action: "DELETE_USER",
                entityType: "User",
                entityId: id,
                description: "User deleted"
            );

            return true;
        }

        public async Task<object> UpdateUserStatusAsync(int userId, bool isActive)
        {
            var user = await _context.Users.FindAsync(userId);

            if (user == null)
                throw new Exception("User not found");

            user.IsActive = isActive;
            user.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            // 🔥 LOG
            await _auditLogService.LogAsync(
                userId: userId,
                module: "USERS",
                action: isActive ? "ACTIVATE_USER" : "SUSPEND_USER",
                entityType: "User",
                entityId: userId,
                description: isActive ? "User activated" : "User suspended"
            );

            return new
            {
                message = isActive ? "User activated" : "User suspended"
            };
        }

        public async Task<object> UpdateUserRoleAsync(int userId, int roleId)
        {
            var user = await _context.Users
                .Include(u => u.UserRoles)
                .FirstOrDefaultAsync(u => u.Id == userId);

            if (user == null)
                throw new Exception("User not found");

            var oldRoles = user.UserRoles.Select(x => x.RoleId).ToList();

            _context.UserRoles.RemoveRange(user.UserRoles);

            await _context.UserRoles.AddAsync(new UserRole
            {
                UserId = userId,
                RoleId = roleId
            });

            await _context.SaveChangesAsync();

            // 🔥 LOG
            await _auditLogService.LogAsync(
                userId: userId,
                module: "USERS",
                action: "UPDATE_ROLE",
                entityType: "User",
                entityId: userId,
                description: $"Role updated from [{string.Join(",", oldRoles)}] to [{roleId}]"
            );

            return new { message = "Role updated successfully" };
        }

        public async Task<object> UpdateUserPermissionsAsync(int roleId, string permissionsJson)
        {
            var role = await _context.Roles
                .Include(r => r.RolePermissions)
                .FirstOrDefaultAsync(r => r.Id == roleId);

            if (role == null)
                throw new Exception("Role not found");

            _context.RolePermissions.RemoveRange(role.RolePermissions);

            var permissions = System.Text.Json.JsonSerializer
                .Deserialize<List<string>>(permissionsJson);

            if (permissions != null)
            {
                foreach (var permName in permissions)
                {
                    var perm = await _context.Permissions
                        .FirstOrDefaultAsync(p => p.Name == permName);

                    if (perm != null)
                    {
                        await _context.RolePermissions.AddAsync(new RolePermission
                        {
                            RoleId = role.Id,
                            PermissionId = perm.Id
                        });
                    }
                }
            }

            await _context.SaveChangesAsync();

            // 🔥 LOG
            await _auditLogService.LogAsync(
                userId: null,
                module: "RBAC",
                action: "UPDATE_PERMISSIONS",
                entityType: "Role",
                entityId: roleId,
                description: "Permissions updated",
                metadata: permissionsJson
            );
            
            return new { message = "Permissions updated successfully" };
        }
    }
}