﻿using Microsoft.EntityFrameworkCore;
using QuickCommerce.Core.DTOs.AdminPermissions;
using QuickCommerce.Core.Entities;
using QuickCommerce.Core.Interfaces;
using QuickCommerce.Infrastructure.Data;
using QuickCommerce.Infrastructure.Services; // ✅ ADDED
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickCommerce.Infrastructure.Services
{
    public class AdminPermissionService : IAdminPermissionService
    {
        private readonly ApplicationDbContext _context;
        private readonly AuditLogService _auditLogService; // ✅ ADDED

        public AdminPermissionService(
            ApplicationDbContext context,
            AuditLogService auditLogService) // ✅ UPDATED
        {
            _context = context;
            _auditLogService = auditLogService;
        }

        public async Task<IEnumerable<PermissionResponseDto>> GetPermissionsAsync()
        {
            return await _context.Permissions
                .Select(p => new PermissionResponseDto
                {
                    Id = p.Id,
                    Name = p.Name,
                    Description = p.Description
                })
                .ToListAsync();
        }

        public async Task<IEnumerable<PermissionResponseDto>> GetRolePermissionsAsync(int roleId)
        {
            return await _context.RolePermissions
                .Where(rp => rp.RoleId == roleId)
                .Join(_context.Permissions,
                    rp => rp.PermissionId,
                    p => p.Id,
                    (rp, p) => new PermissionResponseDto
                    {
                        Id = p.Id,
                        Name = p.Name,
                        Description = p.Description
                    })
                .ToListAsync();
        }

        public async Task<bool> AssignPermissionAsync(int roleId, int permissionId)
        {
            var exists = await _context.RolePermissions
                .AnyAsync(rp => rp.RoleId == roleId && rp.PermissionId == permissionId);

            if (exists)
                return false;

            var rolePermission = new RolePermission
            {
                RoleId = roleId,
                PermissionId = permissionId
            };

            await _context.RolePermissions.AddAsync(rolePermission);
            await _context.SaveChangesAsync();

            // 🔥 AUDIT LOG
            await _auditLogService.LogAsync(
                null,
                "RBAC",
                "ASSIGN_PERMISSION",
                "Role",
                roleId,
                $"Permission {permissionId} assigned to role {roleId}"
            );

            return true;
        }

        public async Task<bool> RemovePermissionAsync(int roleId, int permissionId)
        {
            var mapping = await _context.RolePermissions
                .FirstOrDefaultAsync(x => x.RoleId == roleId && x.PermissionId == permissionId);

            if (mapping == null)
                return false;

            _context.RolePermissions.Remove(mapping);
            await _context.SaveChangesAsync();

            // 🔥 AUDIT LOG
            await _auditLogService.LogAsync(
                null,
                "RBAC",
                "REMOVE_PERMISSION",
                "Role",
                roleId,
                $"Permission {permissionId} removed from role {roleId}"
            );

            return true;
        }
    }
}