﻿using Google.Apis.Auth;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using QuickCommerce.Core.DTOs.Admin;
using QuickCommerce.Core.DTOs.Customer;
using QuickCommerce.Core.Entities;
using QuickCommerce.Core.Interfaces;
using QuickCommerce.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace QuickCommerce.Infrastructure.Services
{
    public class AuthService : IAuthService
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public AuthService(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // =========================
        // USER LOOKUP
        // =========================
        public async Task<User?> GetUserByPhoneAsync(string phoneNumber)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.PhoneNumber == phoneNumber);
        }

        // =========================
        // JWT GENERATION (FIXED)
        // =========================
        public async Task<string> GenerateAccessTokenAsync(User user)
        {
            var userRoles = await _context.UserRoles
                .Include(ur => ur.Role)
                    .ThenInclude(r => r.RolePermissions)
                        .ThenInclude(rp => rp.Permission)
                .Where(ur => ur.UserId == user.Id)
                .ToListAsync();

            var role = userRoles.FirstOrDefault()?.Role;

            var claims = new List<Claim>
            {
                new Claim("userId", user.Id.ToString())
            };

            if (role != null)
            {
                claims.Add(new Claim(ClaimTypes.Role, role.Name));
                claims.Add(new Claim("roleScope", role.Scope ?? "PLATFORM"));

                var userStore = await _context.UserStores
                    .FirstOrDefaultAsync(us => us.UserId == user.Id && us.IsPrimary);

                if (role.Scope == "STORE" && userStore != null)
                {
                    claims.Add(new Claim("storeId", userStore.StoreId.ToString()));
                }

                foreach (var rp in role.RolePermissions)
                {
                    claims.Add(new Claim("permission", rp.Permission.Name));
                }
            }
            else
            {
                // CUSTOMER FLOW
                claims.Add(new Claim(ClaimTypes.Role, "CUSTOMER"));
            }

            var jwtSection = _configuration.GetSection("JWT");

            var key = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(jwtSection["SecretKey"]!));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: jwtSection["Issuer"],
                audience: jwtSection["Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(15),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        // =========================
        // REFRESH TOKEN
        // =========================
        private string GenerateRefreshToken()
        {
            var randomBytes = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomBytes);
            return Convert.ToBase64String(randomBytes);
        }

        private async Task<RefreshToken> CreateRefreshTokenAsync(User user)
        {
            var refreshToken = new RefreshToken
            {
                UserId = user.Id,
                Token = GenerateRefreshToken(),
                ExpiresAt = DateTime.UtcNow.AddDays(7),
                CreatedAt = DateTime.UtcNow,
                IsRevoked = false
            };

            _context.RefreshTokens.Add(refreshToken);
            await _context.SaveChangesAsync();

            return refreshToken;
        }

        // =========================
        // SEND OTP
        // =========================
        public Task<string> SendOtpAsync(string phoneNumber)
        {
            return Task.FromResult("123456");
        }

        // =========================
        // VERIFY OTP
        // =========================
        public async Task<(string AccessToken, string RefreshToken, string Role)?>
            VerifyOtpAsync(string phoneNumber, string otp)
        {
            var user = await GetUserByPhoneAsync(phoneNumber);
            if (user == null)
                return null;

            var accessToken = await GenerateAccessTokenAsync(user);
            var refreshToken = await CreateRefreshTokenAsync(user);

            return (accessToken, refreshToken.Token, "CUSTOMER");
        }

        // =========================
        // ADMIN LOGIN
        // =========================
        public async Task<AdminLoginResponseDto?> AdminLoginAsync(AdminLoginRequestDto request)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Email == request.Email);

            if (user == null)
                return null;

            if (!BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash))
                return null;

            var userRoles = await _context.UserRoles
                .Include(ur => ur.Role)
                    .ThenInclude(r => r.RolePermissions)
                        .ThenInclude(rp => rp.Permission)
                .Where(ur => ur.UserId == user.Id)
                .ToListAsync();

            if (!userRoles.Any())
                return null;

            var role = userRoles.First().Role;

            var permissions = role.RolePermissions
                .Select(rp => rp.Permission.Name)
                .Distinct()
                .ToList();

            var accessToken = await GenerateAccessTokenAsync(user);
            var refreshToken = await CreateRefreshTokenAsync(user);

            return new AdminLoginResponseDto
            {
                AccessToken = accessToken,
                RefreshToken = refreshToken.Token,
                UserId = user.Id,
                Role = role.Name,
                RoleScope = role.Scope ?? "PLATFORM",
                Permissions = permissions
            };
        }

        // =========================
        // REFRESH TOKEN
        // =========================
        public async Task<string?> RefreshTokenAsync(string refreshToken)
        {
            var existingToken = await _context.RefreshTokens
                .Include(rt => rt.User)
                .FirstOrDefaultAsync(rt => rt.Token == refreshToken);

            if (existingToken == null ||
                existingToken.IsRevoked ||
                existingToken.ExpiresAt < DateTime.UtcNow)
                return null;

            existingToken.IsRevoked = true;
            existingToken.RevokedAt = DateTime.UtcNow;

            var newRefreshToken = new RefreshToken
            {
                UserId = existingToken.UserId,
                Token = GenerateRefreshToken(),
                ExpiresAt = DateTime.UtcNow.AddDays(7),
                CreatedAt = DateTime.UtcNow,
                IsRevoked = false
            };

            existingToken.ReplacedByToken = newRefreshToken.Token;

            _context.RefreshTokens.Add(newRefreshToken);

            var newAccessToken = await GenerateAccessTokenAsync(existingToken.User);

            await _context.SaveChangesAsync();

            return newAccessToken;
        }

        // =========================
        // LOGOUT
        // =========================
        public async Task<bool> LogoutAsync(string refreshToken)
        {
            var existingToken = await _context.RefreshTokens
                .FirstOrDefaultAsync(rt => rt.Token == refreshToken);

            if (existingToken == null || existingToken.IsRevoked)
                return false;

            existingToken.IsRevoked = true;
            existingToken.RevokedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return true;
        }

        // =========================
        // GOOGLE LOGIN (FINAL FIXED)
        // =========================
        public async Task<(string AccessToken, string RefreshToken)> GoogleLoginAsync(string idToken)
        {
            var payload = await GoogleJsonWebSignature.ValidateAsync(idToken, new GoogleJsonWebSignature.ValidationSettings
            {
                Audience = new[] { _configuration["GoogleAuth:ClientId"] }
            });

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Email == payload.Email);

            if (user == null)
            {
                user = new User
                {
                    Email = payload.Email,
                    PhoneNumber = "",
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                // ✅ ASSIGN CUSTOMER ROLE
                var customerRole = await _context.Roles
                    .FirstOrDefaultAsync(r => r.Name == "CUSTOMER");

                if (customerRole != null)
                {
                    _context.UserRoles.Add(new UserRole
                    {
                        UserId = user.Id,
                        RoleId = customerRole.Id
                    });
                }

                // ✅ CREATE WALLET
                _context.Wallets.Add(new Wallet
                {
                    UserId = user.Id,
                    Balance = 0,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                });

                await _context.SaveChangesAsync();
            }

            var accessToken = await GenerateAccessTokenAsync(user);
            var refreshToken = await CreateRefreshTokenAsync(user);

            return (accessToken, refreshToken.Token);
        }
        public async Task<CustomerProfileDto?> GetCustomerProfileAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);

            if (user == null) return null;

            return new CustomerProfileDto
            {
                UserId = user.Id,
                FullName = user.FullName,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                ProfileImageUrl = user.ProfileImageUrl,
                Gender = user.Gender,
                DateOfBirth = user.DateOfBirth,
                PreferredLanguage = user.PreferredLanguage
            };
        }

        public async Task<bool> UpdateCustomerProfileAsync(int userId, UpdateCustomerProfileDto dto)
        {
            var user = await _context.Users.FindAsync(userId);

            if (user == null) return false;

            user.FullName = dto.FullName ?? user.FullName;
            user.ProfileImageUrl = dto.ProfileImageUrl ?? user.ProfileImageUrl;
            user.Gender = dto.Gender ?? user.Gender;
            user.DateOfBirth = dto.DateOfBirth ?? user.DateOfBirth;
            user.PreferredLanguage = dto.PreferredLanguage ?? user.PreferredLanguage;

            user.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return true;
        }
        public async Task TrackCustomerActivityAsync(int userId, TrackActivityDto dto)
        {
            var activity = new CustomerActivity
            {
                UserId = userId,
                Action = dto.Action,
                EntityId = dto.EntityId,
                Metadata = dto.Metadata
            };

            _context.CustomerActivities.Add(activity);
            await _context.SaveChangesAsync();

            await UpdateCustomerSegment(userId);
        }

        private async Task UpdateCustomerSegment(int userId)
        {
            var orderCount = await _context.Orders.CountAsync(o => o.CustomerId == userId);

            string segment = "NEW";

            if (orderCount >= 10)
                segment = "HIGH_VALUE";
            else if (orderCount >= 3)
                segment = "ACTIVE";

            var existing = await _context.CustomerSegments
                .FirstOrDefaultAsync(x => x.UserId == userId);

            if (existing == null)
            {
                _context.CustomerSegments.Add(new CustomerSegment
                {
                    UserId = userId,
                    Segment = segment
                });
            }
            else
            {
                existing.Segment = segment;
                existing.UpdatedAt = DateTime.UtcNow;
            }

            await _context.SaveChangesAsync();
        }

        public async Task<string> GetCustomerSegmentAsync(int userId)
        {
            var segment = await _context.CustomerSegments
                .FirstOrDefaultAsync(x => x.UserId == userId);

            return segment?.Segment ?? "NEW";
        }
        // =====================================================
        // ENTERPRISE PASSWORD MANAGEMENT
        // =====================================================

        public string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }

        public bool VerifyPassword(string password, string hash)
        {
            return BCrypt.Net.BCrypt.Verify(password, hash);
        }

        public string GenerateTemporaryPassword(int length = 10)
        {
            const string chars =
                "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789@#$%";

            var password = new char[length];

            using var rng = RandomNumberGenerator.Create();

            var bytes = new byte[length];

            rng.GetBytes(bytes);

            for (int i = 0; i < length; i++)
            {
                password[i] = chars[bytes[i] % chars.Length];
            }

            return new string(password);
        }
    }
}