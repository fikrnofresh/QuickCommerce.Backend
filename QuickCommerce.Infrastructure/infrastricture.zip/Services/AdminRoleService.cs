﻿using Microsoft.EntityFrameworkCore;
using QuickCommerce.Core.DTOs.AdminRoles;
using QuickCommerce.Core.Entities;
using QuickCommerce.Core.Interfaces;
using QuickCommerce.Infrastructure.Data;
using QuickCommerce.Infrastructure.Services; // ✅ ADDED
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickCommerce.Infrastructure.Services
{
    public class AdminRoleService : IAdminRoleService
    {
        private readonly ApplicationDbContext _context;
        private readonly AuditLogService _auditLogService; // ✅ ADDED

        public AdminRoleService(
            ApplicationDbContext context,
            AuditLogService auditLogService) // ✅ UPDATED
        {
            _context = context;
            _auditLogService = auditLogService;
        }

        public async Task<RoleResponseDto> CreateRoleAsync(CreateRoleDto dto)
        {
            var role = new Role
            {
                Name = dto.Name,
                Description = dto.Description
            };

            await _context.Roles.AddAsync(role);
            await _context.SaveChangesAsync();

            // 🔥 AUDIT LOG
            await _auditLogService.LogAsync(
                null,
                "RBAC",
                "CREATE_ROLE",
                "Role",
                role.Id,
                $"Role created: {role.Name}"
            );

            return new RoleResponseDto
            {
                Id = role.Id,
                Name = role.Name,
                Description = role.Description
            };
        }

        public async Task<IEnumerable<RoleResponseDto>> GetRolesAsync()
        {
            return await _context.Roles
                .Select(r => new RoleResponseDto
                {
                    Id = r.Id,
                    Name = r.Name,
                    Description = r.Description
                })
                .ToListAsync();
        }

        public async Task<RoleResponseDto?> GetRoleByIdAsync(int id)
        {
            return await _context.Roles
                .Where(r => r.Id == id)
                .Select(r => new RoleResponseDto
                {
                    Id = r.Id,
                    Name = r.Name,
                    Description = r.Description
                })
                .FirstOrDefaultAsync();
        }

        public async Task<bool> UpdateRoleAsync(int id, UpdateRoleDto dto)
        {
            var role = await _context.Roles.FindAsync(id);

            if (role == null)
                return false;

            role.Name = dto.Name;
            role.Description = dto.Description;

            await _context.SaveChangesAsync();

            // 🔥 AUDIT LOG
            await _auditLogService.LogAsync(
                null,
                "RBAC",
                "UPDATE_ROLE",
                "Role",
                role.Id,
                $"Role updated: {role.Name}"
            );

            return true;
        }

        public async Task<bool> DeleteRoleAsync(int id)
        {
            var role = await _context.Roles.FindAsync(id);

            if (role == null)
                return false;

            _context.Roles.Remove(role);

            await _context.SaveChangesAsync();

            // 🔥 AUDIT LOG
            await _auditLogService.LogAsync(
                null,
                "RBAC",
                "DELETE_ROLE",
                "Role",
                id,
                "Role deleted"
            );

            return true;
        }
    }
}